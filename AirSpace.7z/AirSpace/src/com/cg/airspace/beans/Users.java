package com.cg.airspace.beans;

public class Users {
	
	private String name;
	private String userName;
	private String password;
	private String mobileNumber;
	
	
	
	
	@Override
	public String toString() {
		return "Users [name=" + name + ", userName=" + userName + ", password="
				+ password + ", mobileNumber=" + mobileNumber + "]";
	}
	
	
	
	public Users(String name, String userName, String password,
			String mobileNumber) {
		super();
		this.name = name;
		this.userName = userName;
		this.password = password;
		this.mobileNumber = mobileNumber;
	}
	
	
	
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	
	

	
	
}
